<?php
// ============================================================
// MÓDULO: Cierres
// ============================================================

// Días con ventas que NO tienen cierre
function cierres_pendientes(): void {
    requireAuth();
    $rows = db()->query(
        "SELECT v.fecha,
                COUNT(v.id)   AS num_ventas,
                SUM(v.total)  AS total
         FROM ventas v
         LEFT JOIN cierres c ON c.fecha = v.fecha
         WHERE c.id IS NULL
         GROUP BY v.fecha
         ORDER BY v.fecha DESC"
    )->fetchAll();
    jsonOk($rows);
}

function cierres_realizar(): void {
    requireAdmin();
    $d     = requestBody();
    $fecha = $d['fecha'] ?? date('Y-m-d');
    $db    = db();
    $sess  = currentUser();

    // Verificar que no esté ya cerrado
    $existe = $db->prepare("SELECT id FROM cierres WHERE fecha = ?");
    $existe->execute([$fecha]);
    if ($existe->fetch()) jsonError('Ese día ya fue cerrado');

    $stats = $db->prepare("SELECT COUNT(*) AS num, COALESCE(SUM(total),0) AS total FROM ventas WHERE fecha = ?");
    $stats->execute([$fecha]);
    $s = $stats->fetch();

    if ($s['num'] == 0) jsonError('No hay ventas ese día para cerrar');

    $db->beginTransaction();
    try {
        $db->prepare("INSERT INTO cierres (usuario_id, fecha, total, num_ventas) VALUES (?,?,?,?)")
           ->execute([$sess['user_id'], $fecha, $s['total'], $s['num']]);
        $db->prepare("UPDATE ventas SET cerrada = 1 WHERE fecha = ?")->execute([$fecha]);
        $db->commit();
        jsonOk(['ok' => true, 'total' => $s['total'], 'num_ventas' => $s['num']]);
    } catch (Exception $e) {
        $db->rollBack();
        jsonError('Error al realizar el cierre', 500);
    }
}

// ============================================================
// MÓDULO: Reportes
// ============================================================

function reportes_dias(): void {
    requireAuth();
    $rows = db()->query(
        "SELECT
            v.fecha,
            COUNT(v.id)        AS num_ventas,
            SUM(v.total)       AS total,
            MAX(c.id) IS NOT NULL AS cerrado
         FROM ventas v
         LEFT JOIN cierres c ON c.fecha = v.fecha
         GROUP BY v.fecha
         ORDER BY v.fecha DESC
         LIMIT 60"
    )->fetchAll();
    jsonOk($rows);
}

function reportes_resumen(): void {
    requireAuth();
    $db  = db();
    $hoy = date('Y-m-d');

    $hoy_stats = $db->prepare("SELECT COUNT(*) AS num_ventas, COALESCE(SUM(total),0) AS total FROM ventas WHERE fecha = ?");
    $hoy_stats->execute([$hoy]);
    $h = $hoy_stats->fetch();

    $total_acum = $db->query("SELECT COALESCE(SUM(total),0) FROM ventas")->fetchColumn();

    $dias_count = $db->query("SELECT COUNT(DISTINCT fecha) FROM ventas")->fetchColumn();
    $prom_dia   = $dias_count > 0 ? round($total_acum / $dias_count) : 0;

    $top = $db->query(
        "SELECT descripcion, COUNT(*) AS veces, SUM(precio * cantidad) AS total
         FROM venta_items
         GROUP BY descripcion
         ORDER BY veces DESC
         LIMIT 10"
    )->fetchAll();

    jsonOk([
        'hoy'       => $h,
        'acumulado' => $total_acum,
        'prom_dia'  => $prom_dia,
        'top'       => $top,
    ]);
}
