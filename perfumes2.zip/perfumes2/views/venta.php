<!-- ═══ VENTA ═══════════════════════════════════════════ -->
<div class="view on" id="view-venta">
  <div class="card">
    <div class="card-title">Nueva Venta</div>

    <div class="sec">Tipo de producto</div>
    <div class="chips" id="v-tipo-chips"></div>

    <!-- Productos con tamaño -->
    <div id="v-sec-tamano" style="display:none">
      <div class="sec">Tamaño</div>
      <div class="chips" id="v-size-chips"></div>
      <div class="sec">Producto</div>
      <div class="pgrid" id="v-prods-tamano"></div>
    </div>

    <!-- Productos sin tamaño -->
    <div id="v-sec-notamano" style="display:none">
      <div class="sec">Producto</div>
      <div class="pgrid" id="v-prods-notamano"></div>
    </div>

    <div class="row">
      <div class="grp"><label>Precio ($)</label><input type="number" id="v-precio" placeholder="0"></div>
      <div class="grp"><label>Cantidad</label><input type="number" id="v-cant" value="1" min="1"></div>
    </div>
    <div class="grp mb9"><label>Nota (opcional)</label><textarea id="v-nota-item" placeholder="+fragancia extra, color especial..."></textarea></div>
    <button class="add-btn" onclick="cartAdd()">+ Agregar al carrito</button>
  </div>

  <div class="card" id="cart-card" style="display:none">
    <div class="card-title">Carrito</div>
    <div id="cart-list"></div>
    <div class="total-bar"><div class="tl">Total</div><div class="tv" id="cart-total">$0</div></div>
    <div class="grp mb9"><label>Nota de la venta</label><textarea id="v-nota-venta" placeholder="Nombre del cliente, observaciones..."></textarea></div>
    <button class="btn btn-p" onclick="ventaConfirmar()">✓ Confirmar Venta</button>
    <button class="btn btn-d mt8" onclick="cartClear()">✗ Limpiar carrito</button>
  </div>
</div>